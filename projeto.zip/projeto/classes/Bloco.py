import pygame, sys, os, random
from pygame.locals import *

class Bloco(pygame.sprite.Sprite):
    def __init__(self):
        pygame.sprite.Sprite.__init__(self)
        self.directionx = 0
        self.directiony = 0
        self.image, self.rect = load_image("player.jpg")
        self.rect.centerx = 250
        self.rect.centery = 250

    def movimenta(self):
        self.rect.move_ip((self.directionx * 30), (self.directiony * 30))

    def limite(self):
        if self.rect.left <= 0:
            self.rect.left = 0
        elif self.rect.right >= 500:
            self.rect.right = 500
        if self.rect.top <= 0:
            self.rect.top = 0
        elif self.rect.bottom >= 500:
            self.rect.bottom = 500

    def para(self):
        self.directionx = 0
        self.directiony = 0
